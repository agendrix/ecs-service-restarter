"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateAlarmState = exports.fetchPrimaryDeployment = exports.formatCommandInput = exports.fetchAlarmPayload = void 0;
function fetchAlarmPayload(event) {
    var _a;
    const message = (_a = event.Records[0]) === null || _a === void 0 ? void 0 : _a.Sns.Message;
    if (message) {
        return JSON.parse(message);
    }
    else {
        throw new Error(`The SNS event received does not comply with the requirements. Event: ${JSON.stringify(event)}`);
    }
}
exports.fetchAlarmPayload = fetchAlarmPayload;
function formatCommandInput(payload) {
    var _a, _b, _c;
    const metricDimensions = (_a = payload.Trigger) === null || _a === void 0 ? void 0 : _a.Dimensions;
    if (metricDimensions) {
        const cluster = (_b = metricDimensions.find(d => d.name === "ClusterName" /* CLUSTER_NAME */)) === null || _b === void 0 ? void 0 : _b.value;
        const service = (_c = metricDimensions.find(d => d.name === "ServiceName" /* SERVICE_NAME */)) === null || _c === void 0 ? void 0 : _c.value;
        if (cluster && service) {
            return { cluster, service, forceNewDeployment: true };
        }
    }
    throw new Error(`The SNS event received does not comply with the requirements. Payload: ${JSON.stringify(payload)}`);
}
exports.formatCommandInput = formatCommandInput;
function fetchPrimaryDeployment(service) {
    var _a;
    return (_a = service === null || service === void 0 ? void 0 : service.deployments) === null || _a === void 0 ? void 0 : _a.find(d => d.status === "PRIMARY" /* PRIMARY */);
}
exports.fetchPrimaryDeployment = fetchPrimaryDeployment;
function validateAlarmState(payload) {
    if (payload.NewStateValue !== "ALARM" /* ALARM */) {
        throw new Error("This lambda function should only be called when a CloudWatch alarm is transitioning to the ALARM state.");
    }
}
exports.validateAlarmState = validateAlarmState;
