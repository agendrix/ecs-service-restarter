"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.__test__ = void 0;
const client_ecs_1 = require("@aws-sdk/client-ecs");
const handler = async (event) => {
    try {
        const alarmPayload = fetchAlarmPayload(event);
        if (alarmPayload.NewStateValue !== "ALARM")
            return;
        const client = new client_ecs_1.ECSClient({ region: process.env.REGION });
        const input = formatCommandInput(event);
        console.log(`Roll restart request received for service: ${input.service} in cluster: ${input.cluster}`);
        const command = new client_ecs_1.UpdateServiceCommand(input);
        await client.send(command);
        console.log(`Roll restart was successfully started for service: ${input.service} in cluster: ${input.cluster}`);
    }
    catch (error) {
        console.log(error);
    }
};
const fetchAlarmPayload = (event) => {
    var _a;
    const message = (_a = event.Records.shift()) === null || _a === void 0 ? void 0 : _a.Sns.Message;
    if (message) {
        return JSON.parse(message);
    }
    else {
        throw new Error(`The SNS event received does not comply with the requirements. Event: ${JSON.stringify(event)}`);
    }
};
const formatCommandInput = (payload) => {
    const metricDimensions = payload.Trigger.Dimensions;
    const cluster = metricDimensions.find(d => d.Name === "ClusterName").Value;
    const service = metricDimensions.find(d => d.Name === "ServiceName").Value;
    if (cluster && service) {
        return { cluster, service, forceNewDeployment: true };
    }
    throw new Error(`The SNS event received does not comply with the requirements. Event: ${JSON.stringify(event)}`);
};
exports.handler = handler;
exports.__test__ = {
    handler,
    formatCommandInput
};
