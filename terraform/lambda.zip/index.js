"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_ecs_1 = require("@aws-sdk/client-ecs");
const utils_1 = require("./utils");
const handler = async (event) => {
    try {
        const alarmPayload = utils_1.fetchAlarmPayload(event);
        utils_1.validateAlarmState(alarmPayload);
        const client = new client_ecs_1.ECSClient({ region: process.env.REGION });
        const input = utils_1.formatCommandInput(alarmPayload);
        console.log(`Roll restart request received for service: ${input.service} in cluster: ${input.cluster}`);
        const command = new client_ecs_1.UpdateServiceCommand(input);
        const { service } = await client.send(command);
        const deployment = utils_1.fetchPrimaryDeployment(service);
        console.log(`Roll restart was successfully started for service: ${input.service} in cluster: ${input.cluster} with task definition: ${deployment === null || deployment === void 0 ? void 0 : deployment.taskDefinition}. Deployment id: ${deployment === null || deployment === void 0 ? void 0 : deployment.id}`);
    }
    catch (error) {
        console.log(error);
    }
};
exports.handler = handler;
